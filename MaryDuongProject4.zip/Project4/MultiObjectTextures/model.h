struct Model{
    int startCube;
    int countCube;
    int startFloor;
    int countFloor;
    int startDoor;
    int countDoor;
    int startKey;
    int countKey;
    int startCharacter;
    int countCharacter;
};

